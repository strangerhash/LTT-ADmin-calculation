<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class AdminRole extends Model
{
    /**
     * The role that belong to a user.
     */
    // public function user()
    // {
    //     return $this->belongsTo('App\Admin\AdminUser');
    // }
}
