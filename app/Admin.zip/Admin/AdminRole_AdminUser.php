<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\Relations\Pivot;

class AdminRole_AdminUser extends Pivot
{
    //
}
